import { View, Text } from "react-native";

export default function CustomersScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 24 }}>✅ This route is working</Text>
    </View>
  );
}
